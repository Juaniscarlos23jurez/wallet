<?php

namespace AppleWallet\Passbook\Exception;

class PassException extends \Exception
{
} 